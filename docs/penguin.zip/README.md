# Firmware of Hello Penguin

## Intro

All the animation code is put in Test.cpp. There is a main loop in Application.cpp to run different animation functions.


