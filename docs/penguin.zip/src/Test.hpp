//
// HelloPenguin
// ---------------------------------------------------------------------------
// (c)2019 by NWMaker. See LICENSE for details.
// https://nwmaker.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//
#pragma once

#include "Display.hpp"
#include "Helper.hpp"

/// Simple helper methods.
///
namespace Test {

/// Utility Functions for testing

/// create a static color
/// 
void setStaticColor(uint8_t ledIndex, uint8_t r, uint8_t g, uint8_t b);

/// interpoloate two colors into colorSteps
void interpolateColors(uint8_t * pColors);

void fadeTwoColorsIntoEachOther(uint8_t *pColors);

/// Testing functions
void testOneRGB(uint8_t ledIndex);

void testRGBLed();

void test9TwoColorShow();

void test8RGBSmoothColorA();

void test8RGBSmoothColorB();

void alternativeColors(uint8_t numOfColors, uint8_t * pColors);

void test7RGBTwoColors();

void test6RGBSmoothTransition();

void test5RGBCrossfade();

void test4RGBRainbow(uint32_t delay);

void test3RGBRainbow();

void test2RGBChannels();

void test2RGBChannel(uint8_t channel, bool isOn);

void test1RGB();

/// start new patterns
void moveOneColor(uint8_t *pColor, bool isStartFromRight);

void test1Color();

void test2Colors();

void play1act1();

void play1act2();

void play1act3();

}
