//
// Hello Penguin
// ---------------------------------------------------------------------------
// (c)2019 by NWMaker
// https://nwmaker.com
//

#pragma once


// Workaround for Atmel header include to avoid unnecessary warnings
#undef _U
#undef _L
#undef LITTLE_ENDIAN

// Include the header for the chip you use here.
#include "samd20.h"

