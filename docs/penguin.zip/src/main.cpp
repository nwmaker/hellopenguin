//
// Hello Penguin
// ---------------------------------------------------------------------------
// (c)2019 by NWMaker.
// https://nwmaker.com
//

#include "Application.hpp"

#include "Chip.hpp"


/// The main method of the firmware.
///
int main(void)
{
    SystemInit();
    Application::initialize();
}
