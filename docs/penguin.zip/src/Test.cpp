//
// Hello Penguin
// ---------------------------------------------------------------------------
// (c)2019 by NWMaker. See LICENSE for details.
// https://nwmaker.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//
#include "Test.hpp"

#include "Display.hpp"
#include "Helper.hpp"

namespace Test {
	
void testOneRGB(uint8_t ledIndex)
{
	Display::setAllLedLevels(0);
        Display::setChannelLevel(ledIndex*3, Display::cMaximumLevel);
      	for (uint8_t j = 0; j < 3; ++j) {
        for (uint8_t i = 0; i < 10; ++i) {
                Display::setChannelLevel(ledIndex*3+j, Display::cMaximumLevel);
                Display::synchronizeAndShow();
                Helper::delayMs(200);
                Display::setLedLevel(ledIndex*3+j, 0);
                Display::synchronizeAndShow();
                Helper::delayMs(200);
        }
	}
}

void testRGBLed()
{
        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < Display::cLedChannelCount; ++i) {
                Display::setChannelLevel(i, Display::cMaximumLevel);
                Display::synchronizeAndShow();
                Helper::delayMs(300);
                Display::setChannelLevel(i, 0);
                Display::synchronizeAndShow();
                Helper::delayMs(300);
        }
}

/// create a static color
///
void setStaticColor(uint8_t ledIndex, uint8_t r, uint8_t g, uint8_t b)
{
	Display::setChannelLevel(ledIndex*3+0, r);
	Display::setChannelLevel(ledIndex*3+1, g);
	Display::setChannelLevel(ledIndex*3+2, b);
}

// two globals to avoid dynamic memory allocation
//
uint8_t gColorStep = 16;
uint8_t gInterpolated[16][3];

void interpolateColors(uint8_t * pColors)
{
        // this assumes that pColors has two colors.
        // each color has three components, r, g, and b.
        // the first color is the source,
        // the second color is the destination.
        uint8_t r1, r2, g1, g2, b1, b2;
        int8_t deltaR, deltaG, deltaB;
        r1 = pColors[0];
        g1 = pColors[1];
        b1 = pColors[2];
        r2 = pColors[3];
        g2 = pColors[4];
        b2 = pColors[5];
        deltaR = (r2 - r1)/gColorStep;
        deltaG = (g2 - g1)/gColorStep;
        deltaB = (b2 - b1)/gColorStep;
        for (uint8_t step = 0; step < gColorStep; step++) {
                gInterpolated[step][0] = r1 + deltaR*step;
                gInterpolated[step][1] = g1 + deltaG*step;
                gInterpolated[step][2] = b1 + deltaB*step;
        }
}

// this is a utility function
void fadeTwoColorsIntoEachOther(uint8_t *pColors)
{
	uint8_t flag = 0;
        uint8_t numOfLeds = 10;
        interpolateColors(pColors);

	Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < gColorStep; i++) {
        for (uint8_t j = 0; j < numOfLeds; j++) {
                flag = j%2;
                if (flag == 0) {
                Display::setChannelLevel(j*3, gInterpolated[i][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[i][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[i][2]);
                } else {
                Display::setChannelLevel(j*3, gInterpolated[gColorStep-i-1][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[gColorStep-i-1][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[gColorStep-i-1][2]);
                }
        }
                Display::synchronizeAndShow();
                Helper::delayMs(128);
        }
}

void test9TwoColorShow()
{
	uint8_t colors[4][3] = {
                {64, 0, 0},
                {0, 0, 64},        
                {0, 0, 64},
                {64, 0, 0},        
	};
	fadeTwoColorsIntoEachOther(&colors[0][0]);
	fadeTwoColorsIntoEachOther(&colors[2][0]);
}

void test8RGBSmoothColorA()
{
        uint8_t colors[2][3] = {
                {64, 0, 0},
                {0, 64, 0},
        };
        uint8_t flag = 0;
        uint8_t numOfLeds = 10;
        interpolateColors(&colors[0][0]);

        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < gColorStep; i++) {
        for (uint8_t j = 0; j < numOfLeds; j++) {
                flag = j%2;
                if (flag == 0) {
                Display::setChannelLevel(j*3, gInterpolated[i][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[i][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[i][2]);
                } else {
                Display::setChannelLevel(j*3, gInterpolated[gColorStep-i-1][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[gColorStep-i-1][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[gColorStep-i-1][2]);
                }
        }
                Display::synchronizeAndShow();
                Helper::delayMs(256);
	}
}

void test8RGBSmoothColorB()
{
        uint8_t colors[2][3] = {
                {0, 64, 0},
                {64, 0, 0},
        };
        uint8_t flag = 0;
        uint8_t numOfLeds = 10;
        interpolateColors(&colors[0][0]);

        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < gColorStep; i++) {
        for (uint8_t j = 0; j < numOfLeds; j++) {
                flag = j%2;
                if (flag == 0) {
                Display::setChannelLevel(j*3, gInterpolated[i][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[i][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[i][2]);
                } else {
                Display::setChannelLevel(j*3, gInterpolated[gColorStep-i-1][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[gColorStep-i-1][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[gColorStep-i-1][2]);
                }
        }
                Display::synchronizeAndShow();
                Helper::delayMs(256);
        }
}

/// test: 2 color mix pattern
/// 128 is OK, or it's bit too fast.
///
void alternativeColors(uint8_t numOfColors, uint8_t * pColors)
{
	uint8_t numOfLeds = 10;
	uint8_t k = 0;
	Display::setAllRGBLevels(0);
	for (uint8_t i = 0; i < 60; i++) {
	for (uint8_t j = 0; j < numOfLeds; j++) {
		k = (i + j)%numOfColors;
		Display::setChannelLevel(j*3, pColors[3*k]);
		Display::setChannelLevel(j*3+1, pColors[3*k+1]);
		Display::setChannelLevel(j*3+2, pColors[3*k+2]);
	}
                Display::synchronizeAndShow();
                Helper::delayMs(128);
	}
}

void test7RGBTwoColors()
{
	uint8_t numOfColors = 6;
	uint8_t colors[numOfColors*3] = {
		64, 0, 0,
		0, 64, 0,
		0, 0, 64,
		64, 64, 0,
		0, 64, 64,
		64, 0, 64,
	};
	alternativeColors(2, colors);
	alternativeColors(3, colors);
	alternativeColors(4, colors);
	alternativeColors(5, colors);
	alternativeColors(6, colors);
	alternativeColors(5, colors);
	alternativeColors(4, colors);
	alternativeColors(3, colors);
	alternativeColors(2, colors);
}

/// smooth a color dynamically
///
void test6RGBSmoothTransition()
{
	uint8_t r = 0;
	uint8_t g = 0;
	uint8_t b = 0;

	uint8_t numOfColors = 20;
	uint8_t destColor[numOfColors][3] = {
		{0, 0, 0},  // black
		{64, 0, 0}, // Red
		{0, 64, 0}, // Green
		{0, 0, 64}, // blue
		{64, 0, 0}, // Red
		{32, 32, 0}, // light yellow
		{0, 64, 0}, // Green
		{64, 64, 0}, // yellow
		{32, 0, 32}, // light purples
		{0, 0, 64}, // light purples
		{64, 0, 64}, // purple
		{0, 64, 64}, // aqua
		{64, 0, 0},
		{0, 64, 0},
		{0, 0, 64},
		{64, 0, 64}, // purple
		{64, 64, 0},
		{0, 64, 64},
		{0, 0, 64},
		{32, 32, 32},
	};

	for (uint8_t c = 0; c < numOfColors; c++) {
		while ( r != destColor[c][0] || 
			g != destColor[c][1] ||
			b != destColor[c][2]) {
			if (r < destColor[c][0]) {
				r += 1;
			}
			if (r > destColor[c][0]) {
				r -= 1;
			}
			if (g < destColor[c][1]) {
				g += 1;
			}
			if (g > destColor[c][1]) {
				g -= 1;
			}
			if (b < destColor[c][2]) {
				b += 1;
			}
			if (b > destColor[c][2]) {
				b -= 1;
			}
			for (uint8_t i = 0; i < 10; i++) {
				setStaticColor(i, r, g, b);
			}
			Display::synchronizeAndShow();
                        Helper::delayMs(16); 
		}
	}
}

uint8_t rainbow[10][3] = {
	{64, 0, 0},  // red
	{60, 28, 0}, // orange, 64, 64, 0
	{64, 54, 0},  // yellow, 64, 0, 0
	{0, 64, 0},  // green	
	{0, 0, 64},  // blue
	{0, 12, 22}, // indigo 
	{32, 0, 32}, // purple 35, 0, 64
	{48, 0, 64},
	{32, 32, 32}
};

void test5RGBCrossfade()
{
	uint8_t color[3] = {64, 0, 0};

	Display::setAllRGBLevels(0);
	// start from all red
	for (uint8_t i = 0; i < 10; i++) {
		Display::setChannelLevel(i*3, color[0]);
	}
	Display::synchronizeAndShow();
	Helper::delayMs(32);
	for (uint8_t j = 0; j < 3; j++) {
		for (uint8_t dec = 0; dec < 3; dec++) {
			uint8_t inc = (dec == 2 ? 0 : (dec+1));
			for (uint8_t k = 0; k < 64; k++) {
				color[dec] -= 1;
				color[inc] += 1;
				for (uint8_t i = 0; i < 10; i++) {
					setStaticColor(i, color[0], color[1], color[2]);
				}
				Display::synchronizeAndShow();
				Helper::delayMs(16);				
			}
		}
	}
}

void test4RGBRainbow(uint32_t delay)
{
	// clear all
        Display::setAllRGBLevels(0);
        uint8_t k = 0;
	for (uint8_t j = 0; j < 50; j++) {
	Display::setAllRGBLevels(0);
	for (uint8_t i = 0; i < 10; i++) {
		k = (i + j)%10;
		Display::setChannelLevel(i*3, rainbow[k][0]);
                Display::setChannelLevel(i*3+1, rainbow[k][1]);
                Display::setChannelLevel(i*3+2, rainbow[k][2]);
	}
	Display::synchronizeAndShow();
	Helper::delayMs(delay);
	}
}

void test3RGBRainbow()
{
	for (uint8_t j = 0; j < 3; ++j) {
        Display::setAllRGBLevels(0);
	for (uint8_t i = 0; i < 10; ++i) {
		setStaticColor(i, rainbow[i][0], rainbow[i][1], rainbow[i][2]);
	}
	Display::synchronizeAndShow();
	Helper::delayMs(568);
        Display::setAllRGBLevels(0);
	Display::synchronizeAndShow();
	Helper::delayMs(32);
	}
}

void test2RGBChannels()
{
	for (uint8_t j = 0; j < 3; j++) {
		Display::setAllRGBLevels(0);
	for (uint8_t i = 0; i < 10; i++) {
		Display::setChannelLevel(3*i+j, 32);
		Display::synchronizeAndShow();
                Helper::delayMs(300);
	}
	}
}

/// Test2: each channel of RGB Led is turned on and off.
///
void test2RGBChannel(uint8_t channel, bool isOn)
{
	if ( isOn == true) {
        	Display::setAllRGBLevels(0);
        	for (uint8_t i = 0; i < 10; ++i) {
                	Display::setChannelLevel(3*i+channel, Display::cMaximumLevel);
        	}
        	Display::synchronizeAndShow();
        	Helper::delayMs(300);
  	} else {
        	Display::setAllRGBLevels(0);
        	for (uint8_t i = 0; i < 10; ++i) {
                	Display::setChannelLevel(3*i+channel, 0);
        	}
        	Display::synchronizeAndShow();
        	Helper::delayMs(300);
	}
}

/// Test1: each channel of RGB Led is turned on and off.
///
void test1RGB()
{
        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < Display::cLedChannelCount; ++i) {
                Display::setChannelLevel(i, Display::cMaximumLevel);
                Display::synchronizeAndShow();
                Helper::delayMs(100);
                Display::setChannelLevel(i, 0);
                Display::synchronizeAndShow();
                Helper::delayMs(100);
        }
}

/// start new patterns
/// only one pixel is turned on at a time.
/// we have ten pixels with penguin.
/// here the pixel is the LED instead of independent LED channels.
///
void moveOneColor(uint8_t *pColor, bool isStartFromRight)
{
	Display::setAllRGBLevels(0);
	if (true == isStartFromRight) {
	for (uint8_t i = 0; i < 10; i++ ) {
		Display::setChannelLevel(3*i, pColor[0]);
		Display::setChannelLevel(3*i+1, pColor[1]);
		Display::setChannelLevel(3*i+2, pColor[2]);
              	Display::synchronizeAndShow();
        	Helper::delayMs(64);

		Display::setAllRGBLevels(0);
        	Display::synchronizeAndShow();
        	Helper::delayMs(64);
	}
	} else {
	for (uint8_t j = 0; j < 10; j++ ) {
		Display::setChannelLevel(3*(9-j), pColor[0]);
		Display::setChannelLevel(3*(9-j)+1, pColor[1]);
		Display::setChannelLevel(3*(9-j)+2, pColor[2]);
              	Display::synchronizeAndShow();
        	Helper::delayMs(64);

		Display::setAllRGBLevels(0);
        	Display::synchronizeAndShow();
        	Helper::delayMs(64);
	}
	}
}

/// 
/// one color is breathing at its position (0~9 starting from the right side)
/// with one background color in the second
///
void breatheOneColorWithBK(uint8_t *pColor, uint8_t pos)
{
	// assume the steps is for each component
	//
        uint8_t color[3] = {0, 0, 0};
        uint8_t steps = 16;
	uint8_t colorStep[3] = {0, 0, 0};

	for (uint8_t i = 0; i < 3; i++)
	{
		color[i] = pColor[i];
	}

	for (uint8_t i = 0; i < 3; i++)
	{
		colorStep[i] = pColor[i]/steps;
	}

	for (uint8_t j = 0; j < 10; j++) {
		Display::setChannelLevel(3*j, pColor[3]);
                Display::setChannelLevel(3*j+1, pColor[4]);
                Display::setChannelLevel(3*j+2, pColor[5]);	
	}

	for (uint8_t i = 0; i < steps; i++) 
	{
		Display::setChannelLevel(3*pos, color[0]-i*colorStep[0]);
                Display::setChannelLevel(3*pos+1, color[1]-i*colorStep[1]);
                Display::setChannelLevel(3*pos+2, color[2]-i*colorStep[2]);
		Display::synchronizeAndShow();
                Helper::delayMs(64);	
	}		
	for (uint8_t i = 0; i < steps; i++) 
	{
		Display::setChannelLevel(3*pos, i*colorStep[0]);
                Display::setChannelLevel(3*pos+1, i*colorStep[1]);
                Display::setChannelLevel(3*pos+2, i*colorStep[2]);
		Display::synchronizeAndShow();
                Helper::delayMs(64);
	} 
}

void breatheOneColor(uint8_t *pColor, uint8_t pos)
{
        // assume the steps is for each component
        //
        uint8_t color[3] = {0, 0, 0};
        uint8_t steps = 16;
        uint8_t colorStep[3] = {0, 0, 0};

        for (uint8_t i = 0; i < 3; i++)
        {
                color[i] = pColor[i];
        }

        for (uint8_t i = 0; i < 3; i++)
        {
                colorStep[i] = pColor[i]/steps;
        }

        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < steps; i++)
        {
                Display::setChannelLevel(3*pos, color[0]-i*colorStep[0]);
                Display::setChannelLevel(3*pos+1, color[1]-i*colorStep[1]);
                Display::setChannelLevel(3*pos+2, color[2]-i*colorStep[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
        }
        for (uint8_t i = 0; i < steps; i++)
        {
                Display::setChannelLevel(3*pos, i*colorStep[0]);
                Display::setChannelLevel(3*pos+1, i*colorStep[1]);
                Display::setChannelLevel(3*pos+2, i*colorStep[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
	}
}

void breatheTwoColors(uint8_t *pColor, uint8_t* pPos)
{
        // assume the steps is for each component
        //
        uint8_t color[6] = {
		0, 0, 0, 
		0, 0, 0,
	};
        uint8_t steps = 16;
        uint8_t colorStep[6] = {
		0, 0, 0, 
		0, 0, 0,
	};

        for (uint8_t i = 0; i < 6; i++)
        {
                color[i] = pColor[i];
        }

        for (uint8_t i = 0; i < 6; i++)
        {
                colorStep[i] = pColor[i]/steps;
        }

        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < steps; i++)
        {
                Display::setChannelLevel(3*pPos[0], color[0]-i*colorStep[0]);
                Display::setChannelLevel(3*pPos[0]+1, color[1]-i*colorStep[1]);
                Display::setChannelLevel(3*pPos[0]+2, color[2]-i*colorStep[2]);

                Display::setChannelLevel(3*pPos[1], color[3]-i*colorStep[3]);
                Display::setChannelLevel(3*pPos[1]+1, color[4]-i*colorStep[4]);
                Display::setChannelLevel(3*pPos[1]+2, color[5]-i*colorStep[5]);

                Display::synchronizeAndShow();
                Helper::delayMs(64);
        }
        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < steps; i++)
        {
                Display::setChannelLevel(3*pPos[0], i*colorStep[0]);
                Display::setChannelLevel(3*pPos[0]+1, i*colorStep[1]);
                Display::setChannelLevel(3*pPos[0]+2, i*colorStep[2]);

                Display::setChannelLevel(3*pPos[1], i*colorStep[3]);
                Display::setChannelLevel(3*pPos[1]+1, i*colorStep[4]);
                Display::setChannelLevel(3*pPos[1]+2, i*colorStep[5]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
        }
}


/// 
/// Move two colors in one direction, both are from right or left
/// Bit 
/// 7 : start from right or left side?
/// 6 : move in the same direction or opposite?
/// 3~0 : how far apart between two colors?
///
void moveTwoColors(uint8_t *pColor, uint8_t flag)
{
	uint8_t dist = flag & 0x0F;
	bool isRight = ((flag & 0x80) == 0x80) ? true : false;
	bool isSame = ((flag & 0x40) == 0x40) ? true : false;
	uint8_t pos1 = 0;
	uint8_t pos2 = 0;
	uint8_t color1[3] = {0, 0, 0};
	uint8_t color2[3] = {0, 0, 0};

	for (uint8_t i = 0; i < 3; i++) {
		color1[i] = pColor[i];
		color2[i] = pColor[3+i];
	}

	Display::setAllRGBLevels(0);
	if (isRight == true) {
		if (isSame == true) {

	for (uint8_t j = 0; j < 10; j++) {
		pos1 = j;
		pos2 = (pos1 + dist)%10;
		Display::setChannelLevel(3*pos1, color1[0]);
                Display::setChannelLevel(3*pos1+1, color1[1]);
                Display::setChannelLevel(3*pos1+2, color1[2]);
		Display::setChannelLevel(3*pos2, color2[0]);
                Display::setChannelLevel(3*pos2+1, color2[1]);
                Display::setChannelLevel(3*pos2+2, color2[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
		Display::setAllRGBLevels(0);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
	}	
	
		} else {

	for (uint8_t j = 0; j < 10; j++) {
		pos1 = j;
		pos2 = (9 >= (pos1 + dist)) ? 
			(9 - (pos1+dist))%10 : 
			(19 - (pos1+dist))%10;
		Display::setChannelLevel(3*pos1, color1[0]);
                Display::setChannelLevel(3*pos1+1, color1[1]);
                Display::setChannelLevel(3*pos1+2, color1[2]);
		Display::setChannelLevel(3*pos2, color2[0]);
                Display::setChannelLevel(3*pos2+1, color2[1]);
                Display::setChannelLevel(3*pos2+2, color2[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
		Display::setAllRGBLevels(0);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
	}	

		}
	} else {
		if (isSame == true) {

	for (uint8_t j = 0; j < 10; j++) {
		pos1 = 9 - j;
		pos2 = (pos1+dist)%10;
		Display::setChannelLevel(3*pos1, color1[0]);
                Display::setChannelLevel(3*pos1+1, color1[1]);
                Display::setChannelLevel(3*pos1+2, color1[2]);
		Display::setChannelLevel(3*pos2, color2[0]);
                Display::setChannelLevel(3*pos2+1, color2[1]);
                Display::setChannelLevel(3*pos2+2, color2[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
		Display::setAllRGBLevels(0);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
	}	
 
		} else {

	for (uint8_t j = 0; j < 10; j++) {
		pos1 = 9-j;
		pos2 = (9 >= (pos1+dist)) ? 
			(9 - (pos1+dist))%10 : 
			(19 - (pos1+dist))%10;
		Display::setChannelLevel(3*pos1, color1[0]);
                Display::setChannelLevel(3*pos1+1, color1[1]);
                Display::setChannelLevel(3*pos1+2, color1[2]);
		Display::setChannelLevel(3*pos2, color2[0]);
                Display::setChannelLevel(3*pos2+1, color2[1]);
                Display::setChannelLevel(3*pos2+2, color2[2]);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
		Display::setAllRGBLevels(0);
                Display::synchronizeAndShow();
                Helper::delayMs(64);
	}	

		}
	}	
}

/// only one color is in use
/// The pixel is turned on one after another without turning off
/// delay changed from 128 to 64
void continueOneColor(uint8_t *pColor, bool isStartFromRight)
{
        Display::setAllRGBLevels(0);
        if (true == isStartFromRight) {
        for (uint8_t i = 0; i < 10; i++ ) {
                Display::setChannelLevel(3*i, pColor[0]);
                Display::setChannelLevel(3*i+1, pColor[1]);
                Display::setChannelLevel(3*i+2, pColor[2]);
              	Display::synchronizeAndShow();
        	Helper::delayMs(64);
        }
        } else {
        for (uint8_t j = 0; j < 10; j++ ) {
                Display::setChannelLevel(3*(9-j), pColor[0]);
                Display::setChannelLevel(3*(9-j)+1, pColor[1]);
                Display::setChannelLevel(3*(9-j)+2, pColor[2]);
              	Display::synchronizeAndShow();
        	Helper::delayMs(64);
        }
        }

        Display::setAllRGBLevels(0);
        Display::synchronizeAndShow();
        Helper::delayMs(64);
}

void test1Color() 
{
	uint8_t colors[30] = {
		32, 0, 0,
		0, 32, 0,
		0, 0, 32,
		64, 0, 0,
		32, 32, 0,
		0, 64, 0,
		0, 32, 32,
		0, 0, 64,
		32, 0, 32,
	        64, 0, 0,
	};
	uint8_t numOfColors = 10;

	for (uint8_t i = 0; i < numOfColors; i++)
	{
	continueOneColor(&colors[3*i], true);
	continueOneColor(&colors[3*i], false);
	}
/*
	for (uint8_t i = 0; i < numOfColors; i++)
	{
	moveOneColor(&colors[3*i], true);
	moveOneColor(&colors[3*i], false);
	}
*/
}

void test2Colors()
{
        uint8_t colors[24][3] = {
                {64, 0, 0},
                {0, 64, 0},
                {0, 64, 0},
                {64, 0, 0},

                {0, 64, 0},
                {0, 0, 64},
                {0, 0, 64},
                {0, 64, 0},

                {0, 0, 64},
                {64, 0, 0},
                {64, 0, 0},
                {0, 0, 64},

                {64, 0, 0},
                {32, 32, 0},
                {32, 32, 0},
                {64, 0, 0},

                {0, 64, 0},
                {0, 32, 32},
                {0, 32, 32},
                {0, 64, 0},

                {0, 0, 64},
                {32, 0, 32},
                {32, 0, 32},
                {0, 0, 64},
        };
        uint8_t flag = 0;
        uint8_t numOfLeds = 10;

	for (uint8_t k = 0; k < 12; k++) 
	{
        interpolateColors(&colors[2*k][0]);

        Display::setAllRGBLevels(0);
        for (uint8_t i = 0; i < gColorStep; i++) {
        for (uint8_t j = 0; j < numOfLeds; j++) {
                flag = j%2;
                if (flag == 0) {
                Display::setChannelLevel(j*3, gInterpolated[i][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[i][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[i][2]);
                } else {
                Display::setChannelLevel(j*3, gInterpolated[gColorStep-i-1][0]);
                Display::setChannelLevel(j*3+1, gInterpolated[gColorStep-i-1][1]);
                Display::setChannelLevel(j*3+2, gInterpolated[gColorStep-i-1][2]);
                }
        }
                Display::synchronizeAndShow();
                Helper::delayMs(64);	// changed from 128
        }
	}
}

void play1act3()
{
	uint8_t colors[6] = {
		64, 0, 0,
		0, 64, 0,
	};
	uint8_t pos[6] = {
		1,
		6,
		2,
		5,
		3,
		4,
	};
	moveTwoColors(&colors[0], 0xC5);
        moveTwoColors(&colors[0], 0xC4);
        moveTwoColors(&colors[0], 0xC3);
        moveTwoColors(&colors[0], 0xC2);
        moveTwoColors(&colors[0], 0xC1);

	for (uint8_t i = 0; i < 6; i++)
	{
		breatheTwoColors(colors, pos);
	}
	for (uint8_t i = 0; i < 6; i++)
	{
		breatheTwoColors(colors, &pos[2]);
	}
	for (uint8_t i = 0; i < 6; i++)
	{
		breatheTwoColors(colors, &pos[4]);
	}
        moveTwoColors(&colors[0], 0xC1);
        moveTwoColors(&colors[0], 0xC1);
        moveTwoColors(&colors[0], 0xC1);
}

void play1act2()
{
	uint8_t numOfColors = 10;
	uint8_t colors[3*numOfColors] = {
		64, 0, 0,
		0, 64, 0,
		0, 0, 64,
		0, 64, 64,
		64, 64, 0,
		64, 0, 64,
		0, 32, 32,
		32, 32, 0,
		0, 64, 0,
		64, 0, 0,
	};
        uint8_t color2[6] = {
		64, 0, 0,
		0, 32, 32
	};

	for (uint8_t j = 0; j < numOfColors; j++)
	{
		breatheOneColor(&colors[3*j], j);
	}
	
	breatheOneColorWithBK(color2, 3);
}

void play1act1()
{
	uint8_t colors[18] = {
		48, 0, 0,
		0, 48, 0,
		48, 48, 0,
		48, 0, 48,
		0, 0, 48,
		48, 0, 0,
	};

        moveOneColor(&colors[0], true);
        moveOneColor(&colors[3], false);
        moveOneColor(&colors[6], true);
        moveOneColor(&colors[9], true);

	// 11000011 = 0xC3, right, same, dist from 5 to 1
	moveTwoColors(&colors[0], 0xC5);
	moveTwoColors(&colors[0], 0xC4);
	moveTwoColors(&colors[0], 0xC3);
	moveTwoColors(&colors[0], 0xC2);
	moveTwoColors(&colors[0], 0xC1);

	// 00000011 = 0x03, right, same, dist from 5 to 1
	moveTwoColors(&colors[0], 0x05);
	moveTwoColors(&colors[0], 0x04);
	moveTwoColors(&colors[0], 0x03);
	moveTwoColors(&colors[0], 0x02);
	moveTwoColors(&colors[0], 0x01);

	moveTwoColors(&colors[3], 0xC5);
	moveTwoColors(&colors[3], 0xC4);
	moveTwoColors(&colors[3], 0xC3);
	moveTwoColors(&colors[3], 0xC2);
	moveTwoColors(&colors[3], 0xC1);
	moveTwoColors(&colors[3], 0x05);
	moveTwoColors(&colors[3], 0x04);
	moveTwoColors(&colors[3], 0x03);
	moveTwoColors(&colors[3], 0x02);
	moveTwoColors(&colors[3], 0x01);

	moveTwoColors(&colors[6], 0xC5);
	moveTwoColors(&colors[6], 0xC4);
	moveTwoColors(&colors[6], 0xC3);
	moveTwoColors(&colors[6], 0xC2);
	moveTwoColors(&colors[6], 0xC1);
	moveTwoColors(&colors[6], 0x05);
	moveTwoColors(&colors[6], 0x04);
	moveTwoColors(&colors[6], 0x03);
	moveTwoColors(&colors[6], 0x02);
	moveTwoColors(&colors[6], 0x01);
}

}
