//
// Hello Penguin
// ---------------------------------------------------------------------------
// (c)2019 by NWMaker.
// https://nwmaker.com
//

#include "Application.hpp"
#include "Test.hpp"

#include "Display.hpp"
#include "ElapsedTimer.hpp"
#include "Hardware.hpp"
#include "Helper.hpp"
#include "SceneManager.hpp"
#include "Scene.hpp"
#include "Player.hpp"

#include "Chip.hpp"


namespace Application {
	
	
// Forward declarations.
void onDataReceived(uint32_t value);
void onSynchronization();

	
/// The application state
///
enum class State {
	/// The current scene is playing.
	///
	Play,
	
	/// Master sent the next scene index and waiting to send the synchronization.
	///
	SendSynchronization, 
	
	/// Blend the scene.
	///
	/// Master is waiting for the synchronization finished to be sent which
	/// triggers the blend.
	///
	/// Slave received the synchronization and starts the blend.
	///
	BlendScene,
};
	
/// The scenes to display.
///
const Scene::Name cScenesOnDisplay[] = {
	Scene::SkyWithStars,
	//Scene::IceSparkle,
	//Scene::Waves,
	Scene::Circles,
	
	//Ignore the simple scenes for production release.
	//Scene::SimpleRandomFlicker,
	//Scene::SimpleRandomParticle,
	//Scene::SimpleRotation,
	//Scene::SimpleDiagonal,
	//Scene::SimpleShift,
	//Scene::SimpleFlash,
};

/// The number of scenes to display.
///
const uint8_t cScenesOnDisplayCount = sizeof(cScenesOnDisplay)/sizeof(Scene::Name);

/// Duration of a scene blend in frames.
///
const uint32_t cBlendDuration = 80;

/// Duration how long a scene is shown in milliseconds.
///
const uint32_t cSceneDuration = 60000;


/// The mask for a command.
///
const uint32_t cCmdMask = 0xffff0000ul;

/// The mask for the "next scene" command.
///
const uint32_t cCmdNextScene = 0xa5140000ul;

/// The mask for the scene index portion.
///
const uint32_t cCmdNextScene_SceneMask = 0x000000fful;

/// The mask for the scene entropy portion.
///
const uint32_t cCmdNextScene_EntropyMask = 0x0000ff00ul;


/// The index of the next scene to display.
///
volatile uint8_t gNextSceneIndex = 0;

/// The entropy for the next scene to display.
///
volatile uint8_t gNextSceneEntropy = 0;


/// The state of the application.
///
volatile State gState = State::Play;

/// The elapsed timer to measure the length of a scene.
///
ElapsedTimer gSceneElapsedTime;


/// Display an error state with the LEDs of the board.
///
__attribute__((noreturn))
void displayError(uint8_t errorCode)
{
	while (true) {
		Display::setLedLevel(errorCode, Display::cMaximumLevel);
		Display::synchronizeAndShow();
		Helper::delayMs(500);	
		Display::setLedLevel(errorCode, 0);
		Display::synchronizeAndShow();
		Helper::delayMs(500);
	}
}

/// The initialization for a board in master mode.
///
void masterInitialize()
{
	// Decide about the first scene to display.
	gNextSceneIndex = Helper::getRandom8(0, cScenesOnDisplayCount-1);
	gNextSceneEntropy = Helper::getRandom8(0, 0xff);
		
	// Send the scene number to all other boards.
	Helper::delayMs(50);

	// Blend to the first scene from black.
	Player::displayScene(Scene::Black, 0);
	Player::blendToScene(cScenesOnDisplay[gNextSceneIndex], gNextSceneEntropy, cBlendDuration);
	gSceneElapsedTime.start();
	while (Player::getState() == Player::State::Blend) {
		Player::animate();
	}
}


/// The initialization for a board in slave mode.
///
void slaveInitialize()
{
	Player::displayScene(Scene::Black, 0);
}


void initialize()
{
	// Initialize all modules.
	Hardware::initialize();
	Helper::initialize();
	Display::initialize();
	SceneManager::initialize();
	Player::initialize();

	//Test::play1act1();
	Test::play1act2();
	Test::play1act3();
	Test::test1Color();
	Test::test2Colors();

	//Test::test2RGBChannels();
	Test::test9TwoColorShow();
        //Test::test1RGB();

	Test::test8RGBSmoothColorA();
	Test::test8RGBSmoothColorB();
	Test::test8RGBSmoothColorA();
	Test::test8RGBSmoothColorB();

	Test::test7RGBTwoColors();

	Test::test4RGBRainbow(16);
	//Test::test4RGBRainbow(32);
	//Test::test4RGBRainbow(64);
	//Test::test4RGBRainbow(128);
	//Test::test4RGBRainbow(64);
	//Test::test4RGBRainbow(32);
	//Test::test4RGBRainbow(16);

	Test::test6RGBSmoothTransition();
	Test::test7RGBTwoColors();

	Test::test5RGBCrossfade();

        //Test::test2RGBChannel(1, true);
        //Test::test2RGBChannel(1, false);

	while(true) {
	
	Test::test7RGBTwoColors();
	Test::test4RGBRainbow(256);
	Test::test4RGBRainbow(128);
	Test::test4RGBRainbow(64);
	Test::test4RGBRainbow(32);
	Test::test4RGBRainbow(16);
	Test::test4RGBRainbow(32);
	Test::test4RGBRainbow(64);
	Test::test4RGBRainbow(128);
	Test::test4RGBRainbow(256);
	Test::test5RGBCrossfade();
	Test::test6RGBSmoothTransition();
	Test::test7RGBTwoColors();
	Test::test4RGBRainbow(256);
	Test::test4RGBRainbow(128);
	Test::test4RGBRainbow(64);
	Test::test4RGBRainbow(32);
	Test::test4RGBRainbow(16);
	Test::test4RGBRainbow(32);
	Test::test4RGBRainbow(64);
	Test::test4RGBRainbow(128);
	Test::test4RGBRainbow(256);
	};

	masterInitialize();
}

/*
/// The loop for a board in master mode.
///
__attribute__((noreturn))
void masterLoop()
{
	while (true) {
		// Animate the current scene.
		Player::animate();
		// Check if blending is required/wanted.
		if (cScenesOnDisplayCount > 1 || cTraceBlendOnSingleScene) {
			// Check if its time to think about the next scene
			if (gState == State::Play && gSceneElapsedTime.elapsedTime() > (cSceneDuration - 50)) {
				// Select a random new scene, which is not the currently played one.
				auto nextScene = Helper::getRandom8(0, cScenesOnDisplayCount-1);
				while (nextScene == gNextSceneIndex && cScenesOnDisplayCount != 1) {
					nextScene = Helper::getRandom8(0, cScenesOnDisplayCount-1);
				}
				gNextSceneIndex = nextScene;
				gNextSceneEntropy = Helper::getRandom8(0, 0xff);
				gState = State::SendSynchronization;
			} else if (gState == State::SendSynchronization && gSceneElapsedTime.elapsedTime() >= cSceneDuration) {

				gState = State::BlendScene;
			} else if (gState == State::BlendScene) {
				Player::blendToScene(cScenesOnDisplay[gNextSceneIndex], gNextSceneEntropy, cBlendDuration);
				gState = State::Play;
				gSceneElapsedTime.start();
			}			
		}
	}	
}

*/

/// The function to receive data from the master.
///
void onDataReceived(uint32_t value)
{
	// Check incoming commands.
	if ((value & cCmdMask) == cCmdNextScene) {
		gNextSceneIndex = static_cast<uint8_t>(value & cCmdNextScene_SceneMask);
		gNextSceneEntropy = static_cast<uint8_t>((value & cCmdNextScene_EntropyMask) >> 8);
	}
}


/// The function to receive the synchronization from the master.
///
void onSynchronization()
{
	gState = State::BlendScene;
}


/// The loop for a board in slave mode.
///
__attribute__((noreturn))
void slaveLoop()
{
	while (true) {
		// Animate the current scene.
		Player::animate();
		// Act on application states
		if (gState == State::BlendScene) {
			Player::blendToScene(cScenesOnDisplay[gNextSceneIndex], gNextSceneEntropy, cBlendDuration);
			gState = State::Play;			
		}
	}
}


}
